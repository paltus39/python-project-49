ITERATIONS = 3
INSTRUCTION_CALC = 'What is the result of the expression?'
INSTRUCTION_EVEN = 'Answer "yes" if the number is even, otherwise answer "no".'
INSTRUCTION_GCD = 'Find the greatest common divisor of given numbers.'
INSTRUCTION_PRIME = 'Answer "yes" if given number is prime. \
Other answer "no".'
INSTRUCTION_PROGRESSION = 'What number is missing in the progression?'
MATH_SIGNS = ['+', '-', '*']
MIN_PROGRESSION_LENGHT, MAX_PROGRESSION_LENGHT = 5, 10
