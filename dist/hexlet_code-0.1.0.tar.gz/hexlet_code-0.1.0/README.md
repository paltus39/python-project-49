### Hexlet tests and linter status:
[![Actions Status](https://github.com/paltus39/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/paltus39/python-project-49/actions)

### Maintainability Badge
<a href="https://codeclimate.com/github/paltus39/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/33735da7f8c440e1ec57/maintainability" /></a>
